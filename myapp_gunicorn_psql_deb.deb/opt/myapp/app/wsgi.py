from app import app  # Импорт Flask-приложения из app.py

if __name__ == "__main__":
    app.run()
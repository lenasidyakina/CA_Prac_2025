from app import appl  # Импорт Flask-приложения из app.py

# if __name__ == "__main__":
appl.run()